package com.loan.online.model.customer;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "lsa_cust_acc_det", catalog = "lsadb")
@TableGenerator(name = "lsa_account_det_gen", allocationSize = 1, initialValue = 1, catalog = "lsadb", table = "lsa_tab_gen", pkColumnName = "name", valueColumnName = "name", pkColumnValue = "acc_id")
public class AccountDetails implements Serializable{

	private static final long serialVersionUID = 1L;

	private int id;
	private String accNo;
	private String bankName;
	private String branchName;
	private String ifscCode;
	private String micrNo;
	private String accountType;
	
	@Id
	@GeneratedValue(generator = "lsa_account_det_gen", strategy = GenerationType.TABLE)
	@Column(name = "acc_id")
	public int getId() {
		return id;
	}
	@Column(name = "account_no")
	public String getAccNo() {
		return accNo;
	}
	@Column(name = "bank_name", nullable = false, length = 50)
	public String getBankName() {
		return bankName;
	}
	@Column(name = "branch_name", nullable = false, length = 50)
	public String getBranchName() {
		return branchName;
	}
	@Column(name = "ifsc_code", nullable = false)
	public String getIfscCode() {
		return ifscCode;
	}
	@Column(name = "micr_no", nullable = false)
	public String getMicrNo() {
		return micrNo;
	}
	@Column(name = "accounnt_type", length = 100)
	public String getAccountType() {
		return accountType;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	public void setMicrNo(String micrNo) {
		this.micrNo = micrNo;
	}
	
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
}
