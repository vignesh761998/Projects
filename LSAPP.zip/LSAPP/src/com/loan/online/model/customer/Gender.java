package com.loan.online.model.customer;

public enum Gender {
	MALE,FEMALE,OTHERS;
}
