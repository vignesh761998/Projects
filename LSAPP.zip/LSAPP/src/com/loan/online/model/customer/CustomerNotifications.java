package com.loan.online.model.customer;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "lsa_customer_messages", catalog = "lsadb")
@TableGenerator(name = "customer_notfication_gen", allocationSize = 1, initialValue = 1, catalog = "lsadb", table = "lsa_tab_gen",pkColumnName = "name", valueColumnName = "value", pkColumnValue = "not_id")
public class CustomerNotifications implements Serializable{
		
	private static final long serialVersionUID = 1L;
	
	private int sno;
	private String emailId;
	private String messages;
	
	@Id
	@GeneratedValue(generator = "customer_notfication_gen", strategy = GenerationType.TABLE)
	@Column(name = "not_id")
	public int getSno() {
		return sno;
	}
	
	@Column(name = "email_id", nullable = false, unique = true) 
	public String getEmailId() {
		return emailId;
	}
	@Column(name = "messages", length = 250)
	public String getMessages() {
		return messages;
	}
	
	public void setSno(int sno) {
		this.sno = sno;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public void setMessages(String messages) {
		this.messages = messages;
	} 
}
