package com.loan.online.model.customer;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "lsa_cust_guardian_det", catalog = "lsadb", uniqueConstraints = {
		@UniqueConstraint(columnNames = "pan_no", name = "lsa_customer_guardian_details_pan_no_unq"),
		@UniqueConstraint(columnNames = "aadhar_no", name = "lsa_customer_guardian_details_aadhar_no_unq"),
		@UniqueConstraint(columnNames = "mobile_no", name = "lsa_customer_guardian_details_mobile_no_unq")
})
@TableGenerator(name = "guar_det_tab_gen", allocationSize = 1, initialValue = 1, catalog = "lsadb", table = "lsa_tab_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "parent_id")
public class GuardianDetails {

	private int id;
	private String firstName;
	private String lastName;
	private Gender gender;
	private String qualification;
	private String occupation;
	private String panNo;
	private String aadharNo;
	private String mobileNo;
	private float income;
	private Address address;
	
	private CustomerProfile customerProfile;
	
	@Id
	@GeneratedValue(generator = "guar_det_tab_gen",strategy = GenerationType.TABLE)
	@Column(name ="parent_id")
	public int getId() {
		return id;
	}
	@Column(name = "first_name", nullable = false, length = 100)
	public String getFirstName() {
		return firstName;
	}
	@Column(name = "last_name", length = 100)
	public String getLastName() {
		return lastName;
	}
	@Column(name = "gender")
	@Enumerated(EnumType.STRING)
	public Gender getGender() {
		return gender;
	}
	@Column(name = "qualification", length =100)
	public String getQualification() {
		return qualification;
	}
	@Column(name = "occupation", length =100)
	public String getOccupation() {
		return occupation;
	}
	@Column(name = "pan_no")
	public String getPanNo() {
		return panNo;
	}
	@Column(name = "aadhar_no")
	public String getAadharNo() {
		return aadharNo;
	}
	@Column(name = "mobile_no")
	public String getMobileNo() {
		return mobileNo;
	}
	@Column(name = "income")
	public float getIncome() {
		return income;
	}
	
	@Embedded
	public Address getAddress() {
		return address;
	}
	

	@OneToOne
	@JoinColumn(name = "profile_id")
	public CustomerProfile getCustomerProfile() {
		return customerProfile;
	}
	
	public void setCustomerProfile(CustomerProfile customerProfile) {
		this.customerProfile = customerProfile;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public void setIncome(float income) {
		this.income = income;
	}
	public void setAddress(Address address) {
		this.address = address;
	}	
	
}
