package com.loan.online.model.customer;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import com.loan.online.model.loanlog.LoanLog;

@Entity
@Table(name = "lsa_customer_profile", catalog = "lsadb", uniqueConstraints = {
		@UniqueConstraint(columnNames = "mobile_no", name = "lsa_customer_profile_mobile_no_unq"),
		@UniqueConstraint(columnNames = "aadhar_no", name  = "lsa_customer_profile_aadhar_no_unq"),
		@UniqueConstraint(columnNames = "pan_no", name = "lsa_customer_profile_pan_no_unq"),
})
@TableGenerator(name = "cust_prof_tab_gen", allocationSize = 1, initialValue = 1, catalog = "lsadb", table = "lsa_tab_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "profile_id")
public class CustomerProfile {

	private int id;
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	private MaritalStatus maritalStatus;
	private Gender gender;
	private String qualification;
	private String occupation;
	private String panNo;
	private String aadharNo;
	private String mobileNo;
	private float income;
	
	private CustomerCredential customerCredential;
	private Address address;
	private Collection<AccountDetails>  accountDetails = new HashSet<AccountDetails>();
	private Collection<LoanLog>  loanLog = new HashSet<LoanLog>();
	
	
	private GuardianDetails guardianDetails;
	
	@Id
	@Column(name = "profile_id")
	@GeneratedValue(generator = "cust_prof_tab_gen", strategy = GenerationType.TABLE)
	public int getId() {
		return id;
	}
	
	@Column(name = "first_name",nullable = false, length = 100)
	public String getFirstName() {
		return firstName;
	}
	
	@Column(name = "last_name", nullable = false, length = 100)
	public String getLastName() {
		return lastName;
	}
	
	@Temporal(TemporalType.DATE)
	@Column(name = "date_of_birth")
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	
	@Enumerated(EnumType.STRING)
	@Column(name = "marital_status", length = 10)
	public MaritalStatus getMaritalStatus() {
		return maritalStatus;
	}
	
	@Enumerated(EnumType.STRING)
	@Column(name = "gender", length = 10)
	public Gender getGender() {
		return gender;
	}
	
	@Column(name = "qualification", nullable = false, length = 100)
	public String getQualification() {
		return qualification;
	}
	
	@Column(name = "occupation")
	public String getOccupation() {
		return occupation;
	}
	
	@Column(name = "pan_no", nullable = false, length = 100)
	public String getPanNo() {
		return panNo;
	}
	
	@Column(name = "aadhar_no", nullable = false, length = 100)
	public String getAadharNo() {
		return aadharNo;
	}
	
	@Column(name = "mobile_no", nullable = false, length = 100)
	public String getMobileNo() {
		return mobileNo;
	}
	
	@Column(name = "income")
	public float getIncome() {
		return income;
	}
	
	@Embedded
	public Address getAddress() {
		return address;
	}
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name  = "lsa_customer_loan_log", joinColumns = @JoinColumn(name = "profile_id"), inverseJoinColumns = @JoinColumn(name = "loan_id"))
	public Collection<LoanLog> getLoanLog() {
		return loanLog;
	}
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="lsa_cust_acc_det_det", joinColumns = @JoinColumn(name = "profile_id"), inverseJoinColumns = @JoinColumn(name = "acc_id"))
	public Collection<AccountDetails> getAccountDetails() {
		return accountDetails;
	}

	@OneToOne(mappedBy = "customerProfile")
	public GuardianDetails getGuardianDetails() {
		return guardianDetails;
	}
	
	@OneToOne
	@JoinColumn(name = "email_id")
	public CustomerCredential getCustomerCredential() {
		return customerCredential;
	}

	public void setCustomerCredential(CustomerCredential customerCredential) {
		this.customerCredential = customerCredential;
	}


	public void setAccountDetails(Collection<AccountDetails> accountDetails) {
		this.accountDetails = accountDetails;
	}

	public void setLoanLog(Collection<LoanLog> loanLog) {
		this.loanLog = loanLog;
	}

	public void setGuardianDetails(GuardianDetails guardianDetails) {
		this.guardianDetails = guardianDetails;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setSno(int id) {
		this.id = id;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public void setMaritalStatus(MaritalStatus maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public void setIncome(float income) {
		this.income = income;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
}
