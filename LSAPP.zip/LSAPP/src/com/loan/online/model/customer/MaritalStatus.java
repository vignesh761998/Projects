package com.loan.online.model.customer;

public enum MaritalStatus {
	SINGLE,MARRIED;
}
