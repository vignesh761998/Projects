package com.loan.online.model.customer;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "lsa_customer_credential", catalog = "lsadb")
public class CustomerCredential implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String emailId;
	private String password;
	private Boolean activated;
	private String authKey;	
	CustomerProfile customerProfile;
	@Id
	@Column(name = "email_id", nullable = false)
	public String getEmailId() {
		return emailId;
	}
	
	@Column(name = "password", nullable = false)
	public String getPassword() {
		return password;
	}
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "status", nullable = false)
	public Boolean getActivated() {
		return activated;
	}
	
	@Column(name = "auth_key", length = 30, nullable = false)
	public String getAuthKey() {
		return authKey;
	}
	
	@OneToOne(mappedBy = "customerCredential")
	public CustomerProfile getCustomerProfile() {
		return customerProfile;
	}

	public void setCustomerProfile(CustomerProfile customerProfile) {
		this.customerProfile = customerProfile;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setActivated(Boolean activated) {
		this.activated = activated;
	}
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}
}
