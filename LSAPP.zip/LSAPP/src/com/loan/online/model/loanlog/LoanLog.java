package com.loan.online.model.loanlog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "lsa_loan_log", catalog = "lsadb")
@TableGenerator(name = "loan_tab_gen", allocationSize = 1, initialValue = 1, catalog = "lsadb", table = "lsa_tab_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "loan_id")
public class LoanLog implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String accountNo;
	private float loanAmount;
	private String loanType;
	private String bankName;
	private String ifscCode;
	private String branchName;
	
	@Id
	@GeneratedValue(generator = "loan_tab_gen", strategy = GenerationType.TABLE)
	@Column(name = "loan_id")
	public int getId() {
		return id;
	}
	
	@Column(name = "account_no", nullable = false)
	public String getAccountNo() {
		return accountNo;
	}
	
	@Column(name = "loan_amount",nullable = false)
	public float getLoanAmount() {
		return loanAmount;
	}
	
	@Column(name = "bank_name", nullable = false, length = 50)
	public String getBankName() {
		return bankName;
	}
	@Column(name = "branch_name", nullable = false,length = 100)
	public String getBranchName() {
		return branchName;
	}
	@Column(name = "ifse_code")
	public String getIfscCode() {
		return ifscCode;
	}
	@Column(name = "loan_type")
	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public void setId(int id) {
		this.id = id;
	}	
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public void setLoanAmount(float loanAmount) {
		this.loanAmount = loanAmount;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}	
}