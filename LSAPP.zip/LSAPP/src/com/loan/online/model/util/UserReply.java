package com.loan.online.model.util;

import com.loan.online.model.bank.BankCredential;
import com.loan.online.model.customer.CustomerCredential;

public class UserReply {
	
	private boolean status;
	CustomerCredential customerCredential;
	BankCredential bankCredential;
	
	public boolean isStatus() {
		return status;
	}
	
	public CustomerCredential getCustomerCredential() {
		return customerCredential;
	}
	
	public BankCredential getBankCredential() {
		return bankCredential;
	}
	
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	public void setCustomerCredential(CustomerCredential customerCredential) {
		this.customerCredential = customerCredential;
	}
	
	public void setBankCredential(BankCredential bankCredential) {
		this.bankCredential = bankCredential;
	}
	
}
