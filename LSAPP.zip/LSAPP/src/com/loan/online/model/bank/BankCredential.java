package com.loan.online.model.bank;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "lsa_bank_credential", catalog = "lsadb")
public class BankCredential implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String emailId;
	private String password;
	private Boolean activated;
	private String authKey;
	
	private BankProfile bankProfile;

	@Id
	@Column(name = "email_id")
	public String getEmailId() {
		return emailId;
	}
	
	@Column(name = "password", nullable = false, length = 50)
	public String getPassword() {
		return password;
	}
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "status", nullable = false)
	public Boolean getActivated() {
		return activated;
	}
	@Column(name = "auth_key", length = 30, nullable = false)
	public String getAuthKey() {
		return authKey;
	}
	
	@OneToOne(mappedBy = "bankCredential")
	public BankProfile getBankProfile() {
		return bankProfile;
	}
	
	public void setBankProfile(BankProfile bankProfile) {
		this.bankProfile = bankProfile;
	}
	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setActivated(Boolean activated) {
		this.activated = activated;
	}
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

}
