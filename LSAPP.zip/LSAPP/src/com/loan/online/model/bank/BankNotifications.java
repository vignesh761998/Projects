package com.loan.online.model.bank;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "lsa_bank_messages", catalog = "lsadb", uniqueConstraints = 
	@UniqueConstraint(columnNames = "email_id", name = "lsa_bank_notification_email_id_unq")
)
@TableGenerator(name = "bank_notification_gen",  allocationSize = 1, initialValue = 1, catalog = "lsadb", table = "lsa_tab_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "sno")
public class BankNotifications implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private int sno;
	private String emailId;
	private String messages;
	
	@Id
	@GeneratedValue(generator = "bank_notification_gen", strategy = GenerationType.TABLE)
	@Column(name = "sno")
	public int getSno() {
		return sno;
	}
	
	@Column(name = "email_id", nullable = false) 
	public String getEmailId() {
		return emailId;
	}
	
	@Column(name = "messages", length = 250)
	public String getMessages() {
		return messages;
	}
	
	public void setSno(int sno) {
		this.sno = sno;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public void setMessages(String messages) {
		this.messages = messages;
	} 
}

