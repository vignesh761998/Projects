package com.loan.online.model.bank;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "lsa_bank_profile", catalog = "lsadb", uniqueConstraints = {
		@UniqueConstraint(columnNames = "micr_no", name = "lsa_bank_profile_micr_no_unq"),
		@UniqueConstraint(columnNames = "ifsc_no", name = "lsa_bank_profile_ifsc_no_unq")
})
@TableGenerator(name = "bank_prof_gen",  allocationSize = 1, initialValue = 1, catalog = "lsadb", table = "lsa_tab_gen", pkColumnName = "name", valueColumnName = "value", pkColumnValue = "bank_id")
public class BankProfile implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String bankName;
	private String branchName;
	private String ifscCode;
	private String micrNo;
	private String state;
	private String district;
	private int pinCode; 
	
	private BankCredential bankCredential;
	
	@Id
	@Column(name = "bank_id")
	@GeneratedValue(generator = "bank_prof_gen", strategy = GenerationType.TABLE)
	public int getId() {
		return id;
	}
	
	@Column(name = "bank_name", nullable = false)
	public String getBankName() {
		return bankName;
	}
	@Column(name = "branch_name", nullable = false, length = 50)
	public String getBranchName() {
		return branchName;
	}
	@Column(name = "ifsc_no", nullable = false, length =50)
	public String getIfscCode() {
		return ifscCode;
	}
	@Column(name = "micr_no", nullable = false, length =50)
	public String getMicrNo() {
		return micrNo;
	}
	@Column(name = "state", nullable = false)
	public String getState() {
		return state;
	}
	@Column(name = "district", nullable = false, length = 100)
	public String getDistrict() {
		return district;
	}
	
	@OneToOne
	@JoinColumn(name = "email_id")
	public BankCredential getBankCredential() {
		return bankCredential;
	}
	
	@Column(name = "pin_code", nullable = false)
	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public void setBankCredential(BankCredential bankCredential) {
		this.bankCredential = bankCredential;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public void setMicrNo(String micrNo) {
		this.micrNo = micrNo;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setDistrict(String district) {
		this.district = district;
	}	
}
