package com.loan.online.serv;

public enum CredentialStatus {
	
	NOT_ACTIVATED(""),ERROR(""),NOT_AVAILABLE(""),SUCCESS(""),LOGGED("");
	
	private String authKey;
		
	private CredentialStatus(String authKey) {
		this.authKey = authKey;
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}
	
}
