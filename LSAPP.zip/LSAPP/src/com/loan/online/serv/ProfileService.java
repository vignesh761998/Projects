package com.loan.online.serv;

import java.util.Date;

import org.hibernate.Session;

import com.loan.online.model.customer.Address;
import com.loan.online.model.customer.CustomerProfile;
import com.loan.online.model.customer.Gender;
import com.loan.online.model.customer.MaritalStatus;

public class ProfileService extends FactoryService{
	
	public CustomerProfile getCustomerProfile(String emailId,String userType) {
		Session session = this.factory.openSession();
		CustomerProfile customer = session.get(CustomerProfile.class, emailId);
		session.close();
		
		return customer;
	}
	public Boolean insertCustomerProfile(String emailId,String firstName,String lastName,Date dateOfBirth,Gender gender,MaritalStatus maritalStatus,String mobileNo,String aadharNo,String panNo,String qualification,String occupation, Address address) {
		
		Session session = this.factory.openSession();
		
		CustomerProfile customer = session.get(CustomerProfile.class, emailId);
		if(customer != null) {
			customer.setFirstName(firstName);
			customer.setLastName(lastName);
			customer.setDateOfBirth(dateOfBirth);
			customer.setGender(gender);
			customer.setMaritalStatus(maritalStatus);
			customer.setMobileNo(mobileNo);
			customer.setAadharNo(aadharNo);
			customer.setPanNo(panNo);
			customer.setQualification(qualification);
			customer.setOccupation(occupation);
			customer.setAddress(address);
		}
		else {
			return false;
		}
		return true;
	}
}
