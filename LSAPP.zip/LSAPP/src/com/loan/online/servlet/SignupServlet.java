package com.loan.online.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.loan.online.email.EmailService;
import com.loan.online.model.bank.BankCredential;
import com.loan.online.model.customer.CustomerCredential;
import com.loan.online.model.util.UserReply;
import com.loan.online.serv.BankCredentialService;
import com.loan.online.serv.CredentialService;
import com.loan.online.util.CKUtil;

/**
 * Servlet implementation class SignupServlet
 */
@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String emailId = request.getParameter("emailId");
		String password = request.getParameter("password");
		String type = request.getParameter("userType");
		String userType ;
		if(type.equals("customer")) {
			userType = "customer";
		}
		else {
			userType = "banker" ;
		}
		if(userType.equalsIgnoreCase("customer")) {
			
			CredentialService credential = new CredentialService();
			CKUtil.create(response, "email", emailId, 7200);
			CKUtil.create(response, "userType", userType, 7200);
			UserReply reply = credential.create(emailId, password); 
			CustomerCredential customerCredential = reply.getCustomerCredential();
			String key = customerCredential.getAuthKey();
			
			EmailService.send(emailId, "activation of your email Account account Reg", "Confirm Your Account.Your Key is"+key);
			response.sendRedirect("ConfirmAccount.jsp");
		}
		else if(userType.equalsIgnoreCase("banker")) {
			CKUtil.create(response, "email", emailId, 7200);
			CKUtil.create(response, "userType", userType, 7200);
			BankCredentialService credential = new BankCredentialService();
			UserReply reply = credential.create(emailId, password); 
			BankCredential bankCredential = reply.getBankCredential();
			String key = bankCredential.getAuthKey();
			
			EmailService.send(emailId, "activation of your email Account account Reg", "Confirm Your Account.Your Key is"+key);
			response.sendRedirect("ConfirmAccount.jsp");
		}
	}
}