package com.loan.online.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.loan.online.serv.CredentialService;
import com.loan.online.serv.CredentialStatus;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CredentialService credential = new CredentialService();
		String emailId = request.getParameter("emailId");
		String password = request.getParameter("password");
		String userType = request.getParameter("userType");
		
		if(userType.equalsIgnoreCase("customer")) {
			PrintWriter out= response.getWriter();
			CredentialStatus cs = credential.validate(emailId, password);
			if(cs.equals(CredentialStatus.LOGGED)) {
				System.out.println("Servlet");
				out.write("LOGGED");
			}
			else if(cs.equals(CredentialStatus.NOT_ACTIVATED)) {
				out.write("NOT_ACTIVATED");
			}
			else if(cs.equals(CredentialStatus.ERROR)) {
				out.write("ERROR");
			}
			else if(cs.equals(CredentialStatus.NOT_AVAILABLE)) {
				out.write("NOT_AVAILABLE");
			}
			else if(cs.equals(CredentialStatus.SUCCESS)){
				out.write("SUCCESS");
			}
		}
		else if(userType.equalsIgnoreCase("banker")) {
			PrintWriter out= response.getWriter();
			CredentialStatus cs = credential.validate(emailId, password);
			if(cs.equals(CredentialStatus.LOGGED)) {
				System.out.println("Servlet");
				out.write("LOGGED");
			}
			else if(cs.equals(CredentialStatus.NOT_ACTIVATED)) {
				out.write("NOT_ACTIVATED");
			}
			else if(cs.equals(CredentialStatus.ERROR)) {
				out.write("ERROR");
			}
			else if(cs.equals(CredentialStatus.NOT_AVAILABLE)) {
				out.write("NOT_AVAILABLE");
			}
			else if(cs.equals(CredentialStatus.SUCCESS)){
				out.write("SUCCESS");
			}
		}
	}

}
