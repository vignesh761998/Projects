package com.loan.online.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.loan.online.email.EmailService;
import com.loan.online.serv.BankCredentialService;
import com.loan.online.serv.CredentialService;
import com.loan.online.util.CKUtil;

@WebServlet("/forgetPassword")
public class forgetPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public forgetPasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	String userType = CKUtil.get(request, "userType");
    	System.out.println(request.getParameter("emailId"));
    	System.out.println(userType);
    	if(userType.equalsIgnoreCase("customer")) {
	    	String emailId = request.getParameter("emailId");
	    	System.out.println(emailId);
			CredentialService cs = new CredentialService();
			String password = cs.forgetPassword(emailId);
			EmailService.send(emailId, "Your Password", "Password:" + password +"    you can Login with this password");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
    	else if(userType.equalsIgnoreCase("banker")) {
    		String emailId = request.getParameter("emailId");
			System.out.println(emailId);
    		BankCredentialService cs = new BankCredentialService();
			String password = cs.forgetPassword(emailId);
			EmailService.send(emailId, "Your Password", "Password:" + password +"  you can Login with this password");
			request.getRequestDispatcher("login.jsp").forward(request, response);
    	}
	}

}
