package com.loan.online.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.loan.online.model.bank.BankCredential;
import com.loan.online.model.customer.CustomerCredential;
import com.loan.online.serv.BankCredentialService;
import com.loan.online.serv.CredentialService;
import com.loan.online.util.CKUtil;
import com.loan.online.util.HBFactory;

/**
 * Servlet implementation class ConfirmAccountServlet
 */
@WebServlet("/confirm")
public class ConfirmAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ConfirmAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userType = CKUtil.get(request, "userType");
		System.out.println(userType);
		if(userType.equalsIgnoreCase("customer")) {
			String emailId = request.getParameter("emailId");
			String key = request.getParameter("key");
			CredentialService credentialserv = new  CredentialService();
			credentialserv.activate(emailId, key);
			
			String authKey = "";
			SessionFactory sf = HBFactory.get();
			Session session = sf.openSession(); 
			session.beginTransaction();
			CustomerCredential credential = ((Session) session).get(CustomerCredential.class,emailId);
			session.close();
			sf.close();
			authKey = credential.getAuthKey();
			
			if(!key.equals(authKey)) {
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
			else {
				request.getRequestDispatcher("ConfirmAccount.jsp").forward(request, response);
			}		
		}
		else if(userType.equalsIgnoreCase("banker")) {
			
			System.out.println("Hibernate File");
			String emailId = request.getParameter("emailId");
			String key = request.getParameter("key");
			BankCredentialService credentialserv = new  BankCredentialService();
			credentialserv.activate(emailId, key);
			
			String authKey = "";
			SessionFactory sf = HBFactory.get();
			Session session = sf.openSession(); 
			session.beginTransaction();
			BankCredential credential = ((Session) session).get(BankCredential.class,emailId);
			session.close();
			sf.close();
			authKey = credential.getAuthKey();
			if(!key.equals(authKey)) {
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
			else {
				request.getRequestDispatcher("ConfirmAccount.jsp").forward(request, response);
			}		
		}
	}
}
