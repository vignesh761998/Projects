import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Solution {

	public static void main(String[] args) throws IOException{
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
	    Session session=sf.openSession();
	    session.beginTransaction();
	    session.getTransaction().commit();
	    session.close();
	    sf.close();
	}
}