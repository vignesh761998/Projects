import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.web.model.CustomerLogin;
import org.web.util.HBUtil;

public class Solution {

	public static void main(String[] args) {
		SessionFactory sf=HBUtil.get();
		Session session=sf.openSession();
		session.beginTransaction();
		CustomerLogin u=new CustomerLogin();
		u.setEmailID("132152@gmail.com");
		u.setPassword("2634325");
		session.save(u);
		session.getTransaction().commit();
		session.close();
	}
}
