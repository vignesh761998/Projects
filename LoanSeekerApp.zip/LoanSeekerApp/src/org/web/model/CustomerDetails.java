package org.web.model;

import java.util.Date;
import java.sql.Blob;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity(name="customer_details")
public class CustomerDetails {
	@GeneratedValue
	@Column(name ="s_no")
	private Long sno;
	@Id
	@Column(name="email_id",nullable=false)
	private String emailId;
	@Column(name="first_name",nullable=false)
	private String firstName;
	@Column(name="last_name",nullable=false)
	private String lastName;
	@Column(name="profile_photo")
	private Blob profifephoto;
	@Column(name="father_name",nullable=false)
	private String fatherName;
	@Column(name="date_of_birth")
	private Date dateOfBirth;
	@Column(name="sex",nullable=false)
	private String sex;
	@Column(name="marital_status")
	private MaritalStatus maritalStatus;
	@Column(name="qualification",nullable=false)
	private String qualification;
	@Column(name="marks_obtained",nullable=false)
	private String marksObtained;
	@Column(name="occupation",nullable=false)
	private String Occupation;
	@Column(name="income")
	private String income ;
	@Column(name="pan_no",nullable=false)
	private String panNo;
	@Column(name="aadhar_no",nullable=false)
	private String aadharNo;
	@Column(name="state",nullable=false)
	private String state;
	@Column(name="address",nullable=false)
	private String address;
	@Column(name="mobile_no",unique=true)
	private Long mobileNo;
	
	@Embedded
	private AccountDetails accountDetails;

	public Long getSno() {
		return sno;
	}

	public void setSno(Long sno) {
		this.sno = sno;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Blob getProfifephoto() {
		return profifephoto;
	}

	public void setProfifephoto(Blob profifephoto) {
		this.profifephoto = profifephoto;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public MaritalStatus getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(MaritalStatus maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(String marksObtained) {
		this.marksObtained = marksObtained;
	}

	public String getOccupation() {
		return Occupation;
	}

	public void setOccupation(String occupation) {
		Occupation = occupation;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public AccountDetails getAccountDetails() {
		return accountDetails;
	}

	public void setAccountDetails(AccountDetails accountDetails) {
		this.accountDetails = accountDetails;
	}
	
}