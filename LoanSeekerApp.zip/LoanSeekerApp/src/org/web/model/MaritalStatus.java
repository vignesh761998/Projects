package org.web.model;

public enum MaritalStatus {
	SINGLE,MARRIED;
}
