package org.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity(name="bank_login")
public class BankLogin {
	@Id
	@Column(name="email_id",nullable=false,length=64,unique=true)
	private String emailID;
	@Column(name="password",nullable=false,length=100)
	private String password;
	@Column(name="login_code")
	private String loginCode;
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginCode() {
		return loginCode;
	}
	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}
}
