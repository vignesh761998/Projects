package org.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table
@Entity(name="loan_log")
public class SuccessLoansLog {
	@Column(name="email_id",nullable=false)
	private String emailId;
	@Column(name="account_no",nullable=false)
	private Long accountNo;
	@Column(name="loan_amount",nullable=false)
	private float loanAmount;
	@Column(name="bank_name",nullable=false)
	private String bankName;
	@Column(name="branch_name",nullable=false)
	private String branchName;
	@Column(name="ifsc_code",nullable=false)
	private String ifscCode;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public float getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(float loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
}
