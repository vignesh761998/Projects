package org.web.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer_login")
public class CustomerLogin {	
	@Id
	@Column(name="email_id",nullable=false,length=64,unique=true)
	private String emailId;
	@Column(name="password",nullable=false,length=100)
	private String password;
	@Column(name="login_code")
	private String loginCode;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailID(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginCode() {
		return loginCode;
	}
	public void setLoginCode(String loginCode) {
		this.loginCode = loginCode;
	}
}