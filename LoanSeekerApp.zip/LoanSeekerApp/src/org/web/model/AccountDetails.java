package org.web.model;

import javax.persistence.Column;
import javax.persistence.Id;

public class AccountDetails {
	@Id
	@Column(name="email_id",nullable=false)
	private String emailId;
	@Column(name="account_no")
	private Long accountNo;
	@Column(name="bank_name")
	private String bankName;
	@Column(name="ifse_code")
	private String ifscCode;
	@Column(name="branch_name")
	private String branchName;
	@Column(name="account_type")
	private String accountType;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
}
