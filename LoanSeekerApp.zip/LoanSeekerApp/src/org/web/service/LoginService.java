package org.web.service;

public class LoginService {

}
